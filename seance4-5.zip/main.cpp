#include<iostream>
#include<fstream>
#include "board.hpp"
#include "view.hpp"

using namespace std;


int main(){
    char C1, C2;
    int l1 ,c1 , l2 , c2;
    square Plateau2D[L][C];
    string fichier = "text.txt";

    empty_2D(Plateau2D);
    
start_2D(Plateau2D);

   
    for (int i = 0; i < 2; i++){
        // joueur blanc
        cout<< "tour joueur blanc" << endl;

        print_board_color( Plateau2D);

        cout<<"Case de depart (ligne et colonne) :";
        cin>>l1>>C1;

        l1=l1-1;
        c1 = (int) C1 - 97 ;

        while (l1 < 0 || l1 > 7 || c1 < 0 || c1 > 7){
            cout << "coordonné invalide";
            cout<<"Case de depart (ligne et colonne) :";
            cin>>l1>>C1;
            l1=l1-1;
            c1 = (int) C1 - 97 ;
        }
        
        cout<<"piece est : ";
        print_square_color(Plateau2D, l1, c1);
        cout << endl;
    

        
        cout<<"Case d'arrivee (ligne et colonne) :";
        cin>>l2>>C2;

        l2=l2-1;
        c2 = (int) C2 - 97 ;
        
        while (l2 < 0 || l2 > 7 || c2 < 0 || c2 > 7){
            cout << "coordonné invalide";
            cout<<"Case de depart (ligne et colonne) :";
            cin>>l2>>C2;
            l2=l2-1;
            c2 = (int) C2 - 97 ;
        }
          

        move_piece_2D(Plateau2D,l1,c1,l2,c2);

        //jouer noir
        cout << "tour joueur noir" << endl;

        print_board_color( Plateau2D);

        cout<<"Case de depart (ligne et colonne) :";
        cin>>l1>>C1;

        l1=l1-1;
        c1 = (int) C1 - 97 ;

        while (l1 < 0 || l1 > 7 || c1 < 0 || c1 > 7){
            cout << "coordonné invalide";
            cout<<"Case de depart (ligne et colonne) :";
            cin>>l1>>C1;
            l1=l1-1;
            c1 = (int) C1 - 97 ;
        }
        
        cout<<"piece est : ";
        print_square_color(Plateau2D, l1, c1);
        cout << endl;
    

        
        cout<<"Case d'arrivee (ligne et colonne) :";
        cin>>l2>>C2;

        l2=l2-1;
        c2 = (int) C2 - 97 ;
        
        while (l2 < 0 || l2 > 7 || c2 < 0 || c2 > 7){
            cout << "coordonné invalide";
            cout<<"Case de depart (ligne et colonne) :";
            cin>>l2>>C2;
            l2=l2-1;
            c2 = (int) C2 - 97 ;
        }
          

        move_piece_2D(Plateau2D,l1,c1,l2,c2);


    }
    
    cout << "résultat du jeu : " << endl;
    print_board_color( Plateau2D);

    return 0;
}