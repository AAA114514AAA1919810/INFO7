#ifndef   _types_HPP 
#define   _types_HPP 

const int N=64 , L=8 ,C=8;


enum square{
    Ntour,
    Ncavalier, 
    Nfou, 
    Ndame, 
    Nroi, 
    Npion, 
    Btour, 
    Bcavalier, 
    Bfou, 
    Bdame, 
    Broi, 
    Bpion,
    vide,
};

struct Mask{
   int mask[L][C];

} ;

 struct game{
   

 };


 #endif